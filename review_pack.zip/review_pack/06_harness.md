# 06 — Supplied test harness: could not be run

## Status

**The harness file `review_tests.py` does not exist in this environment.**

`sha256 962a4fb1b37fa8e3e69d20dc1070b98737e42968a372fcee3fba6af2dc408148`
(per the review request) could not be computed because there is no file to
hash. A filesystem-wide search found no copy:

```
$ find / -name 'review_tests.py' 2>/dev/null | grep -v proc
(no output)
$ ls -la /content/review_tests.py
ls: cannot access 'review_tests.py': No such file or directory
```

`06_harness_raw/attempt.txt` contains the exact attempted invocation and its
failure:

```
$ python3 review_tests.py --script original=review_pack/scripts/abc_check_original.py \
    --script new=review_pack/scripts/abc_check.py \
    --json review_pack/06_harness.json --raw review_pack/06_harness_raw
python3: can't open file '/content/review_tests.py': [Errno 2] No such file or directory
EXIT=2
```

`06_harness.json` is therefore **not a harness result**; it is a machine-readable
record of the missing input. No PASS/FAIL rows exist. I did not reconstruct or
guess the harness, and I did not edit it (it was never present).

## What was run instead (manual, as requested)

The two inline test files were created under `/tmp/review_tests/` (they are not
part of the corpus; copies are in `corpus_tests/`):

- `dorian.abc` — header `K:G Dorian`
- `aminor.abc` — header `K:A Minor`

Full stdout for both scripts and both files: `06_manual_tests.txt`
(reproduced below). Exact key-signature lines:

| file | original | new |
|---|---|---|
| `dorian.abc` | `HEADER: … K:G Dorian  (key signature: F#)` | `HEADER: … K:G Dorian  (key signature: F#)` |
| `aminor.abc` | `HEADER: … K:A Minor  (key signature: F#, C#, G#)` | `HEADER: … K:A Minor  (key signature: F#, C#, G#)` |

Both scripts treat the mode words as **major** because `key_signature()`'s mode
alternation is lowercase and unanchored (`maj|min|mix|dor|lyd|phr|loc|m`), so
capitalised `Dorian` / `Minor` do not match. Per ABC 2.1 §3.1.14, capitalisation
is ignored and only the first three letters are parsed: G Dorian must be
1 flat, A Minor must be 0 sharps. Both versions are therefore **wrong** on these
two files. This is a pre-existing limitation, not introduced by my changes, and
it is not covered by any "Fixes" bullet (see `08_limits.md`).
