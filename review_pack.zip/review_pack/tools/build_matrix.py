#!/usr/bin/env python3
"""Build the before/after matrix for the review pack. Read-only on the corpus."""
import csv
import glob
import os
import re
import subprocess

ROOT = "/content"
CORPUS = sorted(glob.glob(os.path.join(ROOT, "transcripts", "*", "score.abc")))
SCRIPTS = {
    "orig": os.path.join(ROOT, "review_pack", "scripts", "abc_check_original.py"),
    "new": os.path.join(ROOT, "review_pack", "scripts", "abc_check.py"),
}
RAW = os.path.join(ROOT, "review_pack", "raw")


def parse(txt):
    m = re.search(r"^RESULT: (\w+)", txt, re.M)
    result = m.group(1) if m else "NO_RESULT"
    probs = len(re.findall(r"^  - ", txt, re.M))
    warns = len(re.findall(r"^WARNING:", txt, re.M))
    pcs = [l for l in txt.splitlines() if l.startswith("  pitch classes (onsets):")]
    bars = re.findall(r"bars=(\d+) sounding_bars=(\d+)", txt)
    key = [l for l in txt.splitlines() if l.startswith("HEADER:") or l.startswith("KEY CHANGES:")]
    return result, probs, warns, pcs, bars, key


rows = []
for f in CORPUS:
    rel = os.path.relpath(f, ROOT)
    uid = rel.split("/")[1]
    out = {}
    for tag, script in SCRIPTS.items():
        r = subprocess.run(["python3", script, "check", rel], cwd=ROOT,
                           capture_output=True, text=True)
        txt = r.stdout
        sub = "original" if tag == "orig" else "new"
        with open(os.path.join(RAW, sub, uid + ".txt"), "w") as fh:
            fh.write(txt)
            fh.write(f"EXIT={r.returncode}\n")
        out[tag] = (txt, r.returncode, *parse(txt))
    o, n = out["orig"], out["new"]
    rows.append({
        "file": rel,
        "orig_exit": o[1], "orig_result": o[2], "orig_problems": o[3], "orig_warnings": o[4],
        "new_exit": n[1], "new_result": n[2], "new_problems": n[3], "new_warnings": n[4],
        "output_changed": "yes" if o[0] != n[0] else "no",
        "pitch_classes_changed": "yes" if o[5] != n[5] else "no",
        "bars_changed": "yes" if o[6] != n[6] else "no",
        "key_changed": "yes" if o[7] != n[7] else "no",
    })

cols = list(rows[0].keys())
with open(os.path.join(ROOT, "review_pack", "matrix.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=cols)
    w.writeheader()
    w.writerows(rows)

from collections import Counter
print("rows", len(rows))
print("transitions", Counter((r["orig_result"], r["new_result"]) for r in rows))
print("orig warnings total", sum(r["orig_warnings"] for r in rows))
print("new warnings total", sum(r["new_warnings"] for r in rows))
print("output_changed", sum(r["output_changed"] == "yes" for r in rows))
print("pitch changed", sum(r["pitch_classes_changed"] == "yes" for r in rows))
print("bars changed", sum(r["bars_changed"] == "yes" for r in rows))
print("key changed", sum(r["key_changed"] == "yes" for r in rows))
print("new invalid:", [r["file"] for r in rows if r["new_result"] != "VALID"])
clean = [r for r in rows if r["orig_result"] == "VALID" and r["orig_warnings"] == 0 and r["output_changed"] == "yes"]
print("clean-before changed-after:", [r["file"] for r in clean])
