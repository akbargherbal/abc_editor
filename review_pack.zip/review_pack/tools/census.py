#!/usr/bin/env python3
"""Census of ABC constructs in the 177-score corpus (read-only).

Run from /content:  python3 review_pack/tools/census.py
"""
import glob
import os
import re
from collections import Counter, defaultdict

ROOT = "/content"
FILES = sorted(glob.glob(os.path.join(ROOT, "transcripts", "*", "score.abc")))
BODY_FIELDS = "KMLQVWw"


def uid(f):
    return f.split("/")[-2]


def header_end(lines):
    for i, l in enumerate(lines):
        if re.match(r"^K:", l.strip()):
            return i
    return -1


def inline_hits(pattern):
    hits = []
    for f in FILES:
        for n, l in enumerate(open(f, encoding="utf-8"), 1):
            for m in re.finditer(pattern, l):
                hits.append((uid(f), n, m.group(0), l.strip()))
    return hits


print("=" * 72)
print("A. INLINE FIELDS  (pattern: \\[[A-Za-z]:...)")
print("=" * 72)
for field in ["V", "K", "M", "L"]:
    hits = inline_hits(r"\[%s:[^\]]*\]" % field)
    print(f"\n[{field}:] occurrences={len(hits)} files={len(set(h[0] for h in hits))}")
    for h in hits:
        print(f"  {h[0]} line {h[1]}: {h[3]}")
    if not hits:
        print("  (none)")
allf = inline_hits(r"\[([A-Za-z]):[^\]]*\]")
other = [h for h in allf if not re.match(r"\[[VKML]:", h[2])]
print(f"\nother [X:] inline fields occurrences={len(other)}")
for h in other:
    print(f"  {h[0]} line {h[1]}: {h[3]}")
if not other:
    print("  (none)")

print()
print("=" * 72)
print("B. BODY-LEVEL FIELD LINES (after the header K: line)")
print("=" * 72)
body_hits = defaultdict(list)
for f in FILES:
    lines = open(f, encoding="utf-8").read().splitlines()
    he = header_end(lines)
    for n, l in enumerate(lines, 1):
        if n <= he + 1:
            continue
        m = re.match(r"^([A-Za-z]):", l.strip())
        if m and m.group(1) in BODY_FIELDS:
            body_hits[m.group(1)].append((uid(f), n, l.strip()))
for field in BODY_FIELDS:
    hs = body_hits.get(field, [])
    files = sorted(set(h[0] for h in hs))
    print(f"\n{field}: occurrences={len(hs)} files={len(files)}")
    if field in "KQ":
        for h in hs:
            print(f"  {h[0]} line {h[1]}: {h[2]}")
    for u in files:
        print(f"  {u}")
    if not hs:
        print("  (none)")

print()
print("=" * 72)
print("C. BODY-LEVEL M: LINES ARRIVING WHILE A BAR IS OPEN")
print("  (preceding music line of that voice does not end with '|')")
print("=" * 72)
open_hits, closed = [], 0
for f in FILES:
    lines = open(f, encoding="utf-8").read().splitlines()
    he = header_end(lines)
    voice = "1"
    last_music = {}
    for n, l in enumerate(lines, 1):
        s = l.strip()
        if n <= he + 1 or not s or s.startswith("%"):
            continue
        vm = re.match(r"^V:\s*(\S+)", s)
        if vm:
            voice = vm.group(1)
            continue
        if re.match(r"^M:", s):
            prev = last_music.get(voice)
            if prev is not None and not prev.endswith("|"):
                open_hits.append((uid(f), n, voice, s, prev))
            else:
                closed += 1
            continue
        if re.match(r"^[A-Za-z]:", s):
            continue
        last_music[voice] = s
print(f"open-bar M: lines = {len(open_hits)}")
for h in open_hits:
    print(f"  {h[0]} line {h[1]} voice {h[2]}: {h[3]}")
    print(f"      preceding music line: {h[4]}")
print(f"closed/at-barline M: lines = {closed}")

print()
print("=" * 72)
print("D. DISTINCT K: VALUES (header, body and inline)")
print("=" * 72)
kv = Counter()
kfiles = defaultdict(set)
where = defaultdict(list)
for f in FILES:
    for n, l in enumerate(open(f, encoding="utf-8"), 1):
        s = l.strip()
        m = re.match(r"^K:\s*(.*)$", s) or re.match(r".*\[K:([^\]]*)\]", s)
        if m:
            val = m.group(1).strip()
            kv[val] += 1
            kfiles[val].add(uid(f))
            where[val].append(f"{uid(f)}:{n}")

import importlib.util
spec = importlib.util.spec_from_file_location("orig", os.path.join(ROOT, "review_pack", "scripts", "abc_check_original.py"))
orig = importlib.util.module_from_spec(spec)
spec.loader.exec_module(orig)

long_modes = ["Dorian", "Phrygian", "Lydian", "Mixolydian", "Aeolian", "Locrian",
              "Minor", "Major", "Ionian"]
for val, c in kv.most_common():
    flags = []
    if any(w in val for w in long_modes):
        flags.append("long-mode-name")
    if re.search(r"(?<=\s)[A-Z][a-z]", val):
        flags.append("capital-mode-letter")
    for tok in ["exp", "clef", "HP", "Hp", "none"]:
        if tok in val:
            flags.append(tok)
    sig, ok = orig.key_signature(val)
    sigtxt = ", ".join(f"{k}{'#' * o if o > 0 else 'b' * -o}" for k, o in sig.items()) or "none"
    print(f"  occurrences={c:3d} files={len(kfiles[val]):3d}  {val!r}  "
          f"flags={flags or 'none'}  orig_recognised={ok}  orig_sig={sigtxt}")

print()
print("=" * 72)
print("E. OTHER CONSTRUCTS")
print("=" * 72)
checks = {
    "tuplets (2..9": r"\([2-9]",
    "chord brackets [CEG]": r"\[[A-Ga-g][#b]?[',]*[0-9]*[A-Ga-gz]",
    "grace notes {": r"\{",
    "broken rhythm > or <": r"[<>]",
    "%% directive": r"^%%",
}
for name, pat in checks.items():
    hits = []
    for f in FILES:
        for n, l in enumerate(open(f, encoding="utf-8"), 1):
            if re.search(pat, l, re.M):
                hits.append((uid(f), n, l.strip()))
    print(f"\n{name}: occurrences={len(hits)} files={len(set(h[0] for h in hits))}")
    for h in hits[:10]:
        print(f"  {h[0]} line {h[1]}: {h[2]}")
    if len(hits) > 10:
        print(f"  ... {len(hits) - 10} more")

print("\nX: count > 1 (multiple tunes per file)")
multi = []
for f in FILES:
    xs = sum(1 for l in open(f, encoding="utf-8") if re.match(r"^X:", l.strip()))
    if xs > 1:
        multi.append((uid(f), xs))
print(f"  files={len(multi)}")
for m in multi:
    print(f"  {m[0]} X: lines={m[1]}")

print("\nvoice names (first token after V:)")
vc = Counter()
vfiles = defaultdict(set)
for f in FILES:
    for l in open(f, encoding="utf-8"):
        m = re.match(r"^V:\s*(\S+)", l.strip())
        if m:
            vc[m.group(1)] += 1
            vfiles[m.group(1)].add(uid(f))
for name, c in vc.most_common():
    print(f"  occurrences={c}  {name!r}  files={len(vfiles[name])}")
