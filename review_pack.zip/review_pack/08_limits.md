# 08 — Limits of this check

## Coverage

- `check` was run on **all 177** corpus files with both scripts: no crashes, no
  timeouts, no missing files. [VERIFIED: `matrix.csv`, `raw/original/`,
  `raw/new/`]
- Only the `check` subcommand was run over the whole corpus. `bars` was run only
  on `9ccadbaf…` (Vocal + Ins, both scripts) and on the synthetic/throw-away
  files; `diff` and `fit` were not re-run over the corpus, so this pack does not
  exercise the parts of the script they use beyond import/CLI smoke tests.
- `review_tests.py` was **not run** because it is not present in the environment
  (`06_harness.md`). Consequently there are no harness PASS/FAIL results, and
  none of the docstring claims have harness evidence — only corpus/manual
  evidence.
- `abc_check_original.py` is a hash-verified reconstruction, not a file that was
  on disk; its byte identity is proven by matching the expected sha256
  (`31a68…`). If the reviewer requires the literal file, it must be supplied.
- I did not validate the ABC files with an independent ABC parser (no
  `abc2midi`/`abcm2ps` installed). "All 177 are valid" means *valid according to
  this checker*, not "valid according to every ABC implementation".
- `fit` (lyrics/syllables) and `diff` (edit budget) have no corpus coverage in
  this pack.

## Behavioural changes that weaken validation (not just fix bugs)

1. **Bare body-level `M:` with an open bar** (hunk H7, undocumented): was a hard
   error (`bar not closed with a barline`, exit 1); now a warning and exit 0.
   Corpus impact: **0 files** (`04_census.md` §C). Semantics changed nonetheless.
2. **Inline fields other than `K`/`M`/`L`** (hunk H6): were one unsupported-token
   error per character; now a single `WARNING: inline field X:
   ignored/unsupported`. The field is still dropped. Corpus impact: 0 files.
3. **Invalid inline `K:`/`M:`/`L:` values**: now recorded as a warning
   (`set_key`, `inline_field`) rather than a burst of unsupported-token errors.
   An invalid `[K:...]` therefore cannot make a file INVALID. Corpus impact:
   0 files (no invalid inline key values).
4. **Invalid bare body-level `K:`**: was `inline field K: ignored/unsupported`
   (warning); now `K:<val> not recognised` (warning). Same severity, different
   text.

No `try/except` was removed or added around parsing; the only new `try/except`
blocks are the inline `M:`/`L:` handlers, which convert `parse_meter`/`Fraction`
failures into `sc.errors` (same policy as the existing bare `M:`/`L:` handlers).
No argparse flag, default, threshold or exit code was changed: `check` still
returns `1 if probs else 0`, `diff` still returns `0/1/2`.

## Warnings I chose not to surface / information only

- `KEY CHANGES:` is printed as plain information (not `WARNING:`), so it does
  not count as a warning and does not affect exit status.
- A key change that is a no-op (e.g. `[K:Fm]` when the key is already `Fm`) is
  listed in `KEY CHANGES` with no warning.
- Key signatures are now tracked per voice, but `check` prints only the header
  signature. If two voices end in different keys, the output does not show each
  voice's current key; only the change lines are listed.
- Inline `[V:]`, `[Q:]`, `[P:]` contents are dropped with a single warning;
  the field is not applied. The docstring's "Inline bracketed fields are now
  parsed" can be read as claiming more than this.
- The original's `K:D#m not recognised` warning disappears in the new output
  because the key is now understood — it is not suppressed, it is no longer
  applicable.

## Things in my earlier summary that the evidence does not support

1. **"`K:D#m`/`K:G#m` were *silently* transposed."** Not supportable: the
   original printed `WARNING: K:D#m not recognised; pitch spelling may be off`
   for all 31 `D#m` files and once for `G#m`. The transposition happened *with*
   a warning. Correct wording: "misread with a warning while still reporting
   VALID". See `03_error_causes.md`.
2. **"No genuine score errors anywhere."** Supportable only relative to this
   checker. I did not cross-check with another ABC implementation, so the
   stronger claim "the scores are correct" is not supported.
3. **"All 177 validate"** is true for `abc_check.py` (exit 0, `RESULT: VALID`),
   but not a statement about musical correctness. The reviewer's own
   `K:G Dorian` / `K:A Minor` files illustrate the gap: both scripts call them
   VALID and both compute the wrong key. See `06_notes.md`.
4. **Docstring "Fixes" completeness.** The docstring does not mention H7 (bare
   `M:` deferral), H13 (output format / `KEY CHANGES`), or the warn-and-drop
   behaviour for non-K/M/L inline fields. See `05_changes.md`.
5. **`[M:]` and `[L:]` support** is implemented but unverified against any real
   file in the corpus or against the missing harness.

## What remains broken (known, not fixed in `abc_check.py`)

- Long/capitalised mode names (`K:G Dorian`, `K:A Minor`) are read as major in
  both the original and my version. `abc_check_proposed.py` fixes this but was
  not applied (per the "no new fixes" rule) and could not be harness-tested.

## Reproducibility caveats

- Environment Python is 3.13.16; the transcriber recorded Python 3.11.17. No
  version-specific syntax was used (f-strings, `Fraction`, `re` only), but the
  matrix was not reproduced on 3.11.
- No wall-clock timings were captured for the 354 `check` runs; they completed
  interactively in well under the 600 s command timeout.
- The ABC 2.1 quotations were fetched over the network on 2026-10-27; the raw
  HTTP capture lives outside this pack (path recorded in
  `sources/abc21_excerpts.md`), so the quote itself is reproducible only while
  that URL is available.
