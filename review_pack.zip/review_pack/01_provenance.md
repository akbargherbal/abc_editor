# 01 — Provenance

## Environment

| item | value | label |
|---|---|---|
| Python used for all runs in this pass | `Python 3.13.16` | [VERIFIED: `python3 -V`, output in `env.txt`] |
| OS / kernel | `Linux bdce524ad120 6.6.159+ #1 SMP Thu Oct 22 03:07:54 UTC 2026 x86_64` | [VERIFIED: `uname -a`, output in `env.txt`] |
| Working directory | `/content` | [VERIFIED: `pwd`, output in `env.txt`] |
| Version control | none — `git status` → `fatal: not a git repository` | [VERIFIED: `env.txt`] |
| Shell history | `HISTFILE` empty; `~/.bash_history` does not exist | [VERIFIED: `env.txt`] |

The corpus itself was produced by a separate run whose manifest records
`python: 3.11.17` (`transcripts/transcribe_manifest.json`, `created_utc:
2026-10-25T08:40:08Z`). That is the transcriber's interpreter, not the one used
by `abc_check.py` here. [VERIFIED: `transcripts/transcribe_manifest.json`]

## Script hashes

| file | expected sha256 (review request) | actual sha256 | verdict |
|---|---|---|---|
| `abc_check_original.py` | `31a683221f413683a5c11b3ae6309f21204e77395c6f9c1320d53c6329dd6bb1` | `31a683221f413683a5c11b3ae6309f21204e77395c6f9c1320d53c6329dd6bb1` | MATCH |
| `abc_check.py` (mine) | `e06894436c1cc9d3d54754f532293a408fae0d6dd9b8f386626294b3d5f8b3fd` | `e06894436c1cc9d3d54754f532293a408fae0d6dd9b8f386626294b3d5f8b3fd` | MATCH |
| `review_tests.py` | `962a4fb1b37fa8e3e69d20dc1070b98737e42968a372fcee3fba6af2dc408148` | **file not present** | NOT AVAILABLE |

Raw hash output: `scripts.sha256`.

**Important disclosure.** `abc_check_original.py` was **not on disk** when this
pass started (searched `/` for `abc_check_original.py` and `review_tests.py`;
only `/content/abc_check.py` and `/content/abc_report/abc_check_patched.py`
existed). I wrote `scripts/abc_check_original.py` from the verbatim text of the
script attached to the earlier session prompt, then hashed it. Its sha256 is
byte-for-byte the expected `31a68…`, so this is a hash-verified copy, not a
memory reconstruction. [VERIFIED: `sha256sum`, `scripts.sha256`]

`review_tests.py` has no source anywhere in this environment, so the supplied
harness could not be run (see `06_harness.md`, `06_notes.md`, `08_limits.md`).

## Corpus manifest

- `manifest_corpus.sha256` — 177 lines, `sha256  transcripts/<uuid>/score.abc`.
- Independent witness #1: `transcripts/transcribe_manifest.json` stores
  `abc_sha256` for every track, written `2026-10-25T08:40:08Z`.
- Independent witness #2: `transcripts.zip`, created in the earlier session at
  `2026-10-27T06:48:21Z` (before any edit to `abc_check.py`).

Verification results (raw output in `corpus_vs_manifest.txt`, `zip_vs_corpus.txt`):

```
files 177 manifest entries 177 match 177
mismatches 0
zip score.abc files: 177
working tree score.abc files: 177
mismatches: 0
```

[VERIFIED: `corpus_vs_manifest.txt`, `zip_vs_corpus.txt`]

## Did you modify, create, delete or rename any `.abc` file?

**No.** [VERIFIED: `corpus_vs_manifest.txt`, `zip_vs_corpus.txt`,
`prov_stat.txt`]

Evidence:

1. All 177 current `score.abc` hashes equal the `abc_sha256` values recorded in
   the transcriber manifest on 2026-10-25, two days before this work.
2. All 177 files also equal the copies inside `transcripts.zip`, which was
   created at 06:48 on 2026-10-27, before any editing of the checker.
3. `score.abc` mtimes span `2026-10-27T06:40:55Z`–`2026-10-27T06:45:34Z`; the
   checker's final write is later (`2026-10-27T06:57:54Z`).

Caveat: there is no version-control history and no pre-run backup from before
06:40, so I cannot cryptographically exclude a change made between the
transcription run and the zip; I can only prove the corpus has been stable since
06:48 on 2026-10-27 and that it matches the transcriber's own hashes.

## Did you change any script other than `abc_check.py`?

**No pre-existing script other than `abc_check.py` was modified.**
[VERIFIED: `env.txt` (`ls /content/*.py` shows only `abc_check.py`);
`find / -name 'abc_check*.py'`]

New files created (allowed by the request):

| file | when | purpose |
|---|---|---|
| `abc_report/abc_check_patched.py` | earlier session, 06:52 | throw-away patched copy used to prove the diagnosis; not used in this pass's matrix |
| `review_pack/**` | this pass | this evidence pack, including two diagnostic script copies: `tools/abc_check_no_h7.py` (control with H7 reverted) and `scripts/abc_check_proposed.py` (optional Task 7 proposal) |
| `scripts/abc_check_original.py` | this pass | hash-verified reconstruction of the original (see above) |

`review_tests.py` was never present, so it was neither edited nor run.

## Exact commands from the earlier "corpus validation pass"

No shell history file exists (`HISTFILE` empty). The following list is
transcribed from the earlier session transcript, so its ordering is
**[ASSUMED]**, but every *effect* it describes is re-verified by the artifacts
in this pack. [ASSUMED: session transcript; effects VERIFIED in `prior_run/` and
`raw/`]

```
ls -la /content
ls -la /content/transcripts | head -50
du -sh /content/transcripts
find /content/transcripts -type f | wc -l
find /content/transcripts -maxdepth 2 -mindepth 2 | head -10
gcloud config list | head -20
which gsutil gcloud
cd /content && zip -qr transcripts.zip transcripts && ls -lh transcripts.zip && unzip -l transcripts.zip | tail -3
gsutil -m cp /content/transcripts.zip gs://akbar-december-2024-backup/arabmaqamrock/datasets/five_stars/v1/transcripts.zip
gsutil ls -l gs://akbar-december-2024-backup/arabmaqamrock/datasets/five_stars/v1/
find /content/transcripts -name '*.abc' | wc -l
python3 - <<'EOF'   # runner: subprocess.run(['python3','/content/abc_check.py','check',f]) over 177 files
...
EOF
python3 abc_check.py check transcripts/9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd/score.abc
python3 abc_check.py bars transcripts/9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd/score.abc --voice Vocal
python3 - <<'EOF'   # warning aggregation over all_results.json
...
EOF
sed -n '75,85p;180,190p' transcripts/9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd/score.abc
tail -12 transcripts/9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd/score.abc
grep -n '\[[A-Za-z]:' -r transcripts/*/score.abc
cp abc_check.py abc_report/abc_check_patched.py    # then in-place regex substitutions via a heredoc script
python3 abc_report/abc_check_patched.py check transcripts/9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd/score.abc
python3 abc_report/abc_check_patched.py check transcripts/01821d42-8748-461e-bbf5-5abb2b82fb74/score.abc
python3 -m py_compile abc_check.py
python3 - <<'EOF'   # 177-file runner after edits
...
EOF
python3 abc_check.py diff /tmp/a.abc /tmp/b.abc
python3 abc_check.py bars /tmp/inline_test.abc --voice 1
rm -rf /content/__pycache__
```

No command in that list writes to `transcripts/**` or `*.abc`.

## Files in this directory

| file | contents |
|---|---|
| `env.txt` | `python3 -V`, `uname -a`, `pwd`, `date -u`, git status, `ls *.py` |
| `scripts.sha256` | hashes of the two available scripts |
| `corpus_vs_manifest.txt` | 177/177 match against `transcribe_manifest.json` |
| `zip_vs_corpus.txt` | 177/177 match against `transcripts.zip` |
| `prov_stat.txt` | `.abc` mtime range and session artifact times |
