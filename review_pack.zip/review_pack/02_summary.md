# 02 — Before/after matrix

## Invocation

```
cd /content
python3 review_pack/scripts/abc_check_original.py check transcripts/<uuid>/score.abc
python3 review_pack/scripts/abc_check.py          check transcripts/<uuid>/score.abc
```

Built by `python3 review_pack/tools/build_matrix.py` (script included). Raw
stdout for each run, with the exit code appended as `EXIT=<n>`:

- `raw/original/<uuid>.txt` (177 files)
- `raw/new/<uuid>.txt` (177 files)
- `matrix.csv` (177 rows, columns exactly as requested)

## Column definitions

| column | definition |
|---|---|
| `orig_exit`, `new_exit` | process exit status |
| `orig_result`, `new_result` | first word after `RESULT:` (`VALID` / `INVALID`) |
| `orig_problems`, `new_problems` | count of lines starting `  - ` (the lines printed under `RESULT`) |
| `orig_warnings`, `new_warnings` | count of lines starting `WARNING:` |
| `output_changed` | full stdout differs byte-for-byte (both runs get the same `FILE:` path) |
| `pitch_classes_changed` | any `pitch classes (onsets):` line differs |
| `bars_changed` | any `bars=<n> sounding_bars=<m>` counter differs |
| `key_changed` | the `HEADER:` or `KEY CHANGES:` line differs |

`bars_changed` therefore means "bar count or sounding-bar count changed", not
"bar contents changed"; only one file triggers it, and its bar **count** is
unchanged at 146/146 (see below).

## Result transitions

| orig → new | files |
|---|---|
| VALID → VALID | 176 |
| INVALID → VALID | 1 |
| INVALID → INVALID | 0 |
| VALID → INVALID | 0 |

Totals: original warnings **34** across **33** files; new warnings **0**;
`output_changed = yes` **33** files. [VERIFIED: `matrix.csv`, command above]

## Files where **new is not VALID**

None. Every one of the 177 files has `new_result = VALID` and `new_exit = 0`.
[VERIFIED: `matrix.csv`; `raw/new/`]

## Files that were VALID with **zero** warnings before but changed after

**Empty list.** No previously clean file changed output.
[VERIFIED: `matrix.csv` — query in `tools/build_matrix.py` printed
`clean-before changed-after: []`]

All 33 changed files were already flagged by the original (1 INVALID + 32
VALID-with-warning), so nothing changed silently.

## The 33 files with changed output

### A. `9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd` — INVALID → VALID

Original: 12 problems, 2 warnings, exit 1. New: 0 problems, 0 warnings, exit 0.
Pitch classes, sounding-bar counter and key line all change.
Evidence: `raw/original/9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd.txt`,
`raw/new/9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd.txt`,
`raw/extra/bars_9ccad_{original,new}_*.txt`.

### B. 32 files whose only change is key/pitch reporting (still VALID, 0 problems)

These keep the same bars, same onsets and same exit code; only the key-signature
line and the note-name histogram change because the key is now understood.
`bars_changed = no` for all 32.

`K:D#m` (31 files):

```
01821d42-8748-461e-bbf5-5abb2b82fb74   05b2c11d-e7bb-4c54-acc8-5d57695d57d7
0be82bf8-c5e1-4167-ac70-e031c9f8022c   101835bb-8918-4592-b542-2b13d5d86c2d
13fae855-2a2d-4410-a272-6101a3b9653d   14f449b2-66c3-4200-af25-fc733ca20b55
1a4000af-94f8-4418-8c54-141449893607   1b956cd0-8f9e-4b5c-a00c-9f859e0b7bbc
28df4f0d-1d66-45b1-8766-d457cc45da48   3ba505d0-9602-43e0-9edd-0540c462b274
576c8a9b-8e82-4b78-81a8-36702569804a   678768d6-e4b7-4451-9041-964dc5501fae
6c93c118-fd8d-430b-8fb9-7e0bc86ac50b   6fce90eb-5e78-42cc-a418-a2e00d347d03
7666435c-5831-477a-b8fa-b5b9d463797d   833153ed-2211-44ac-bb99-ab0fe658c64e
9fa58db4-44ab-4b69-b5ba-8c0ad5e321e8   a4c75146-2727-4ff5-a399-ca8a2bb31bab
a9382ab5-feab-44bc-93a4-8c6cafacd7b1   bb17d099-457c-412f-a05e-fee7b3297a6d
c5907965-83ff-4a54-b19e-66baff20202d   cb456914-7b93-4265-af76-824ad11eeb6e
d0fd493c-cada-4dc7-84b3-674abc529db7   d1dc51bc-eb80-4927-95dd-73873939965c
e1b1d293-f7c3-456f-8bbf-58103dabec58   e4a4138a-ff90-4a1c-9103-18a8e41ca3f6
e67207bc-e062-4483-992a-30aef2731097   f2cae6e5-d7fd-432c-b170-39b5c0ffbff3
f81c9bc0-60d0-4d01-8bb4-e5dfc7aec42a   f8293491-f125-48cd-b82e-77cd0460a0cb
f9fa236d-6527-4424-9396-36ff27b1ac13
```

`K:G#m` (1 file): `2701b683-9a51-4512-aaf3-d269235d83de`

Example before/after (`raw/original|new/01821d42….txt`), pitch histogram only:

```
orig: HEADER: ... K:D#m  (key signature: none)
      pitch classes (onsets): E 122, D 116, C 76, A 74, F 54, B 53, G 41
new : HEADER: ... K:D#m  (key signature: F#, C#, G#, D#, A#, E#)
      pitch classes (onsets): F 122, Eb 116, Db 76, Bb 74, F# 54, B 53, Ab 41
```

The onsets/bars are identical (`536` Vocal, `77` Ins); only spelling changes.
[VERIFIED: those two raw files]

## Cross-check against the earlier summary

The earlier summary said "176/177 valid, one checker-caused failure, 32 files
with a key warning". The matrix confirms exactly that. It also confirms the
earlier claim that all 177 files are VALID under the fixed script, with the
caveat recorded in `06_notes.md` / `08_limits.md`: the two reviewer-supplied
long-mode test files (`K:G Dorian`, `K:A Minor`) are still misread by **both**
scripts, but they are not part of the 177-file corpus.
