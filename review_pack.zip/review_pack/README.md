# review_pack — evidence for changes to `abc_check.py`

**Bottom line up front:** the corpus has 177 files. Under the original script
176 were VALID and 1 was INVALID (12 problems); 32 of the VALID files carried a
key-signature warning. All 33 affected files are explained by **checker
limitations**, not score defects. Under the fixed script all 177 are VALID with
0 warnings. **`review_tests.py` was not present in the environment, so Task 6
could not be run** (see `06_harness.md`); nothing below is harness-verified.

## Contents

```
README.md                  this page
01_provenance.md           environment, hashes, read-only evidence
02_summary.md              before/after matrix + lists
03_error_causes.md         cause per file + raw message counts + verdict
04_census.md               construct census (verbatim tool output)
05_changes.md              hunk-by-hunk inventory + docstring verdicts
05_diff.patch              diff -u original → mine
05_no_h7_check.txt         177-file test of abc_check.py vs the same script with H7 reverted
06_harness.md              why the harness could not run + manual K: tests
06_harness.json            machine-readable "not run" record (not a result)
06_notes.md                harness notes, incl. the two K: test files
06_manual_tests.txt        raw check output for K:G Dorian / K:A Minor
06_harness_raw/            attempt log + copy of the manual test output
07_proposal.md             optional proposal (long mode names)
07_proposal_tests.txt      proposed script on the two K: test files
07_corpus_check.txt        177-file new-vs-proposed comparison (0 differ)
08_limits.md               coverage limits, weakened validation, retractions
matrix.csv                 177 rows × the requested columns
manifest_corpus.sha256     sha256 of every corpus score.abc
raw/original/*.txt         177 raw `check` outputs, original, EXIT= appended
raw/new/*.txt              177 raw `check` outputs, mine, EXIT= appended
raw/extra/                 bars evidence (phantom note) + key_signature tests
corpus/<uuid>/score.abc    byte-identical copies of the corpus (hashes match)
corpus_tests/              the two reviewer-supplied K: test files
sources/abc21_excerpts.md  quoted ABC 2.1 evidence
scripts/                   original, mine, proposed, earlier throw-away patch
tools/                     build_matrix.py, census.py, abc_check_no_h7.py (control)
prior_run/                 artifacts from the earlier session
```

Reproduce the matrix with `python3 review_pack/tools/build_matrix.py` (from
`/content`), the census with `python3 review_pack/tools/census.py`.

## The seven questions

### 1. Did you modify any `.abc` file?

**No.** [VERIFIED: `01_provenance.md`, `corpus_vs_manifest.txt`,
`zip_vs_corpus.txt`, `prov_stat.txt`]

All 177 `score.abc` hashes match (a) the `abc_sha256` values recorded by the
transcriber on 2026-10-25 and (b) the copies in `transcripts.zip` created
2026-10-27 06:48, before any checker edit. `score.abc` mtimes are
06:40:55–06:45:34; `abc_check.py` was first edited at 06:57:54. There is no git
history, so I cannot prove anything about the window before 06:40.

### 2. What exactly were the original errors, how many, and of which kinds?

[VERIFIED: `03_error_causes.md`, `matrix.csv`, `raw/original/`]

33 files: **1 INVALID** (12 problem lines) + **32 VALID-with-warning**
(34 warning lines) = 46 diagnostic lines.

| primary cause | files |
|---|---:|
| `inline_K` (`[K:Fm]` tokenised as music) | 1 (`9ccadbaf…`) |
| `sharp_key_unrecognised` (`D#m` 31, `G#m` 1) | 32 |
| `inline_M`, `inline_L`, `mid_bar_M_line`, `other` | 0 |

The invalid file's 12 problems are 10 `unsupported token` lines for
`[`, `K`, `:`, `m`, `]` in two voices, plus 2 spurious
`bar 146: duration 9/16 != meter 1/2 [z4Fz4]` lines caused by the `F` in
`K:Fm` being read as a note.

### 3. Were they score defects or checker limitations?

**Checker limitations.** [VERIFIED: `03_error_causes.md`,
`sources/abc21_excerpts.md`, `raw/extra/bars_9ccad_*.txt`]

- ABC 2.1 §3.2 makes `[K:…]`/`[M:…]`/`[L:…]` valid inline fields, and states
  that a bare body-level `M:` line and its `[M:]` form are "equivalent — either
  variant is equally acceptable".
- ABC 2.1 §3.1.14's table defines `D#m` (6 sharps) and `G#m` (5 sharps) as
  valid keys; the original's table lacked `D#`/`G#`.
- The `9/16` bar is an artefact: with the field stripped the bar is `z4z4`
  (8/16). Raw bars: original `z4Fz4 <-- BAD LENGTH`, mine `z4z4`.
- No genuine bar-length, unterminated-bar or voice-length error exists in the
  corpus (all 177 pass under the fixed checker).

### 4. Which corpus files depend on each documented fix?

[VERIFIED: `02_summary.md`, `04_census.md`, `matrix.csv`]

| fix | corpus files affected | nature |
|---|---:|---|
| F1 inline `[K:]` (+ phantom note) | 1 (`9ccadbaf…`) | INVALID → VALID; onsets 517→516; bars 146 stays 146 |
| F2 bare body `K:` | 1 (`9ccadbaf…`, co-occurring) | pitch reporting only (G→G♭ after `K:Bbm`) |
| F3 `D#m`/`G#m` key table | 32 (31 `D#m`, 1 `G#m`) | key/pitch reporting only; bars and onsets unchanged |
| inline `[M:]` / `[L:]` | 0 | not present in corpus |
| H7 bare `M:` deferral | **0** | all 1380 body `M:` lines are at barlines |

### 5. Did any previously clean file (VALID, no warnings) change output?

**No — the list is empty.** [VERIFIED: `02_summary.md`, `matrix.csv`]

`output_changed = yes` occurs for exactly 33 files: the one INVALID file plus
the 32 files that already had a `K:` warning. Every other file is byte-identical
between the two scripts.

### 6. What changed that you did not document?

[VERIFIED: `05_changes.md`, `05_diff.patch`]

- **H7:** bare body-level `M:` arriving mid-bar used to be a hard error; now the
  bar closes under the old meter and the change is deferred with a warning
  (exit 1 → 0 in that situation). Not in the docstring, 0 corpus files affected.
- **H13:** `check` output now uses `keysig_text()` and adds a `KEY CHANGES:`
  line. Not in the docstring (it is reporting, not a fix).
- **H6:** inline fields other than `K`/`M`/`L` are now warned-and-dropped
  instead of producing per-character errors; the docstring's "inline bracketed
  fields are now parsed" is broader than the implementation.
- Per-voice key signatures are tracked but only the header signature is printed.
- Retraction: the docstring's "**silently** transposed" is wrong — the original
  warned on every `D#m`/`G#m` file.

### 7. What did you not verify?

[VERIFIED: `08_limits.md`, `06_harness.md`, `06_notes.md`]

- The supplied harness: `review_tests.py` is absent, so there are **no**
  PASS/FAIL results (attempt and error in `06_harness_raw/attempt.txt`).
- Inline `[M:]` / `[L:]` handling: implemented, 0 corpus occurrences, untested.
- Independent ABC validity (no `abc2midi`/`abcm2ps` cross-check).
- `fit` and `diff` over the corpus.
- Long/capitalised mode names: both the original and my script misread
  `K:G Dorian` and `K:A Minor` (wrong key, still VALID). The proposal fixes it
  but is not applied and could not be harness-tested.

## Pack-level caveats

- `abc_check_original.py` was reconstructed from the verbatim earlier-session
  attachment and is proven byte-identical by the expected sha256; it was not
  present on disk.
- `corpus/` and `corpus_tests/` are byte-identical copies made for review; the
  working corpus was not touched (hash checks above). Those copies and the two
  reviewer-requested test fixtures are the only `.abc` files created in this
  pass; no working `.abc` was modified, renamed or deleted.
- The ABC 2.1 quotes were fetched on 2026-10-27; the raw HTTP capture is outside
  the pack (path noted in `sources/abc21_excerpts.md`).
