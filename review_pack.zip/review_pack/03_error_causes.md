# 03 — What were the "errors"?

Scope: every corpus file that was INVALID **or** emitted at least one `WARNING:`
under `review_pack/scripts/abc_check_original.py`.

- 177 files run; **33** files qualify.
- 1 INVALID (exit 1), 32 VALID-with-warning (exit 0).
- 12 problem lines + 34 warning lines = 46 diagnostic lines total.
  [VERIFIED: `matrix.csv`; counts re-derived from `raw/original/*.txt`]

## Primary cause per file (one cause per file)

| primary cause | files | file names |
|---|---:|---|
| `inline_K` | 1 | `9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd` |
| `sharp_key_unrecognised` | 32 | 31 × `K:D#m` + 1 × `K:G#m` — full list below |
| `inline_M` | 0 | — |
| `inline_L` | 0 | — |
| `body_K_line` | 0 | — (but see "co-occurring" below) |
| `mid_bar_M_line` | 0 | — |
| `other` | 0 | — |

Full `sharp_key_unrecognised` file list (31 × `K:D#m`, 1 × `K:G#m`):

```
01821d42-8748-461e-bbf5-5abb2b82fb74   05b2c11d-e7bb-4c54-acc8-5d57695d57d7
0be82bf8-c5e1-4167-ac70-e031c9f8022c   101835bb-8918-4592-b542-2b13d5d86c2d
13fae855-2a2d-4410-a272-6101a3b9653d   14f449b2-66c3-4200-af25-fc733ca20b55
1a4000af-94f8-4418-8c54-141449893607   1b956cd0-8f9e-4b5c-a00c-9f859e0b7bbc
28df4f0d-1d66-45b1-8766-d457cc45da48   3ba505d0-9602-43e0-9edd-0540c462b274
576c8a9b-8e82-4b78-81a8-36702569804a   678768d6-e4b7-4451-9041-964dc5501fae
6c93c118-fd8d-430b-8fb9-7e0bc86ac50b   6fce90eb-5e78-42cc-a418-a2e00d347d03
7666435c-5831-477a-b8fa-b5b9d463797d   833153ed-2211-44ac-bb99-ab0fe658c64e
9fa58db4-44ab-4b69-b5ba-8c0ad5e321e8   a4c75146-2727-4ff5-a399-ca8a2bb31bab
a9382ab5-feab-44bc-93a4-8c6cafacd7b1   bb17d099-457c-412f-a05e-fee7b3297a6d
c5907965-83ff-4a54-b19e-66baff20202d   cb456914-7b93-4265-af76-824ad11eeb6e
d0fd493c-cada-4dc7-84b3-674abc529db7   d1dc51bc-eb80-4927-95dd-73873939965c
e1b1d293-f7c3-456f-8bbf-58103dabec58   e4a4138a-ff90-4a1c-9103-18a8e41ca3f6
e67207bc-e062-4483-992a-30aef2731097   f2cae6e5-d7fd-432c-b170-39b5c0ffbff3
f81c9bc0-60d0-4d01-8bb4-e5dfc7aec42a   f8293491-f125-48cd-b82e-77cd0460a0cb
f9fa236d-6527-4424-9396-36ff27b1ac13
2701b683-9a51-4512-aaf3-d269235d83de   <- K:G#m
```

[VERIFIED: `matrix.csv`, `raw/original/*.txt`]

### Co-occurring, not primary

`9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd` also contains two bare body-level
`K:Bbm` lines (79, 82), which the original warned about and ignored
(`body_K_line`). It is assigned `inline_K` because that is what made it INVALID;
the `K:Bbm` warnings did not affect validity. The new script applies both, which
is why this file's pitch histogram also changes. [VERIFIED: raw pair for 9ccad]

## Verbatim minimal excerpts (from real corpus files)

`inline_K` — `transcripts/9ccadbaf-…/score.abc` line 185 (identical at 187):

```
Z|z4[K:Fm]z4|
```

`sharp_key_unrecognised` — header line 8 of `01821d42-…/score.abc`:

```
K:D#m
```

…and of `2701b683-…/score.abc`:

```
K:G#m
```

`body_K_line` (co-occurring only) — `9ccadbaf-…/score.abc` lines 79/82:

```
K:Bbm
```

## Raw message table

Counted from `raw/original/*.txt`; `line N` = any line number, `<val>` = key
value. [VERIFIED: aggregation command in `tools/`/this file's derivation; raw
lines visible in the per-file outputs]

| count | raw message (normalised) |
|---:|---|
| 31 | `WARNING: K:D#m not recognised; pitch spelling may be off` |
| 1 | `WARNING: K:G#m not recognised; pitch spelling may be off` |
| 2 | `WARNING: line N: inline field K: ignored/unsupported` |
| 2 | `  - line 185/187: unsupported token '[' in voice Vocal/Ins` |
| 2 | `  - line 185/187: unsupported token 'K' in voice Vocal/Ins` |
| 2 | `  - line 185/187: unsupported token ':' in voice Vocal/Ins` |
| 2 | `  - line 185/187: unsupported token 'm' in voice Vocal/Ins` |
| 2 | `  - line 185/187: unsupported token ']' in voice Vocal/Ins` |
| 1 | `  - Vocal bar 146: duration 9/16 != meter 1/2  [z4Fz4]` |
| 1 | `  - Ins bar 146: duration 9/16 != meter 1/2  [z4Fz4]` |

## Were the errors score defects or checker limitations?

**Checker limitations.** [VERIFIED: spec excerpts in `sources/abc21_excerpts.md`;
raw outputs]

Evidence:

1. **Inline `[K:…]` is standard ABC 2.1.** §3.2: *"These, and most other
   information fields which can be legally used within the tune body, can be
   specified as an inline field by placing them within square brackets in a line
   of music"*, and the standard's own example shows a bracketed inline `[M:9/8]`
   and a bare body-level `M:9/8` line as *"equivalent — either variant is
   equally acceptable"*. The information-field table marks `K`, `L`, `M` as
   legal in the tune body and as inline fields.
2. **`D#m` and `G#m` are valid keys.** §3.1.14's key-signature table lists
   `D#m` under 6 sharps and `G#m` under 5 sharps. The original's
   `MAJOR_SHARPS` lacked the tonics `D#` and `G#`, so it returned an empty
   signature and its own warning said *"pitch spelling may be off"* — i.e. the
   checker knew it was guessing.
3. **The bar-146 "9/16" is a parser artefact, not a score defect.** The bar text
   is music `z4z4` (8/16) followed by the inline field `[K:Fm]`. The original
   tokenised the `F` inside `K:Fm` as a note, producing `[z4Fz4]` = 9/16. With
   the field removed the bar is `z4z4` and is exactly 1/2. Raw before/after:
   `raw/extra/bars_9ccad_original_Vocal.txt` and
   `raw/extra/bars_9ccad_new_Vocal.txt`.
4. **Bare body-level `K:` is legal in the tune body** (same §3.2/table). The
   original printed `inline field K: ignored/unsupported` and dropped the key
   change, so pitch names after line 79 were computed in `Fm` instead of `Bbm`.

No file in the corpus had a genuine bar-length error: with the checker defects
removed, all 177 validate (`matrix.csv`, `raw/new/`).

### What the "silently" claim in my docstring gets wrong

The docstring bullet says `K:D#m` / `K:G#m` were *"read as 'no key signature',
which **silently** transposed pitch names"*. The transposition is real, but it
was **not silent**: the original printed one `WARNING: K:D#m not recognised; pitch
spelling may be off` per file (31×), and `K:G#m` once. The correct statement is
"misread with a warning, while still reporting VALID". This is corrected in
`05_changes.md` and `08_limits.md`.
