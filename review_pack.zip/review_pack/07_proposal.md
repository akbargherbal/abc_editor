# 07 — Proposal (separate from `abc_check.py`)

`scripts/abc_check_proposed.py` is a **new file**. It does not replace
`abc_check.py` and the matrix in this pack was produced with `abc_check.py`.

## What it changes

One function only: `key_signature()`.

1. Accepts long and capitalised mode names — `G Dorian`, `A Minor`,
   `C Ionian`, `D Mixolydian`, `E Phrygian`, `F Lydian`, `B Locrian` — matching
   ABC 2.1 §3.1.14 ("capitalisation is ignored for the modes and in fact only
   the first three letters of each mode are parsed").
2. Accepts `K:none` / empty `K:` as "no signature" instead of "not recognised".

## Why

The reviewer-supplied files `corpus_tests/dorian.abc` (`K:G Dorian`) and
`corpus_tests/aminor.abc` (`K:A Minor`) are both misread by the original **and**
by `abc_check.py`:

```
abc_check.py  : K:G Dorian  -> key signature: F#          (should be Bb)
abc_check.py  : K:A Minor   -> key signature: F#, C#, G#  (should be none)
proposed      : K:G Dorian  -> key signature: Bb
proposed      : K:A Minor   -> key signature: none
```

Raw output: `06_harness_raw/manual_tests_copy.txt` (current scripts) and
`07_proposal_tests.txt` (proposed).

This is a silent wrong-key bug: the mode word falls through to "major" without
any warning, so pitch names and histograms are wrong while `RESULT: VALID`.
(The long mode names do not occur anywhere in the 177-file corpus —
`04_census.md` §D — so this is about the supplied tests, not the corpus.)

## Effect on the corpus

**None.** Re-running `check` on all 177 files with the proposed script produces
byte-identical stdout and exit codes to `abc_check.py`.

```
corpus files: 177
files differing between new and proposed: 0
```

Raw: `07_corpus_check.txt`. Therefore the "same matrix columns for files whose
result differs" table is empty.

## Harness

`review_tests.py` is absent (`06_harness.md`), so I could **not** run the
required

```
python review_tests.py --script original=... --script new=... --script proposed=...
```

I am not claiming the proposal passes it.

## Status

Proposal only; not applied. It is not covered by the "Fixes" block in
`abc_check.py` (which documents only the corpus-driven changes).
