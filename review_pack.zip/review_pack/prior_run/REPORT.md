# abc_check.py — corpus validation report

> **Status: fixed.** The defects below were repaired in `/content/abc_check.py`
> (see the "Fixes" note in its docstring). Re-running the fixed checker on the
> whole corpus gives **177/177 VALID, 0 warnings**.

Scope: all `transcripts/*/score.abc` (177 files)
Checker (initial run): `/content/abc_check.py` (pre-fix)
Command: `python3 abc_check.py check transcripts/<id>/score.abc`

## Result

| | count |
|---|---|
| Files checked | **177** |
| VALID (exit 0) | **176** |
| INVALID (exit 1) | **1** |
| Crashes / parse exceptions | 0 |

Only one file fails, and the failure is caused by the **checker**, not the score.

## The only failure

`transcripts/9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd/score.abc`

```
line 185: unsupported token '[' ... 'K' ... ':' ... 'm' ... ']'   (Vocal)
line 187: unsupported token '[' ... 'K' ... ':' ... 'm' ... ']'   (Ins)
Vocal bar 146: duration 9/16 != meter 1/2  [z4Fz4]
Ins   bar 146: duration 9/16 != meter 1/2  [z4Fz4]
```

Source (lines 185/187):

```
Z|z4[K:Fm]z4|
```

### Diagnosis: checker bug

`abc_check.py` only understands header-style fields (`K:`, `M:`, … at the start of
a line). It does **not** understand ABC inline bracketed fields such as `[K:Fm]`.
It tokenises the bracket contents as music:

* `[`, `K`, `:`, `m`, `]` → 10 "unsupported token" errors
* the `F` inside `K:Fm` → a **phantom note**, which makes the bar 4+1+4 = 9/16
  instead of 8/16

Evidence: with only the two checker defects fixed (see below), that same file
reports `bar 146: z4z4`, 516 onsets instead of 517, and `RESULT: VALID`.

The score itself is fine here, and the `[K:Fm]` is a no-op anyway (the file's
header key is already `K:Fm`).

## Checker defects found (affect results, not just noise)

1. **No support for bracketed inline fields `[K:...]`, `[M:...]`, `[L:...]`.**
   Blast radius: 1 file (9ccadbaf…), which is the only INVALID result.
   Severity: high for this file (false INVALID + phantom note).

2. **Key-signature table is incomplete.** `MAJOR_SHARPS` has no `G#`, `D#`
   (nor `A#`, `E#`, `B#`, `Fb`). `K:D#m` / `K:G#m` therefore return an empty
   signature with a warning.
   Blast radius: **32 files** — 31 in `D#m`, 1 in `G#m`.
   Effect: validity is unaffected, but every pitch name, range, pitch-class
   histogram and "explicit accidentals" count in those files is **transposed by
   a semitone**. Example (`01821d42…`, `K:D#m`):

   | | pitch classes |
   |---|---|
   | current checker (no signature) | E 122, D 116, C 76, A 74, F 54, B 53, G 41 |
   | correct D#m signature (6♯) | F/E♯ 122, E♭/D# 116, D♭/C# 76, B♭/A# 74, F♯ 54, B 53, A♭/G# 41 |

   The `D#m` reading is the correct one: the written letters (`d g a b`, `C E G A`,
   `D …`) under a 6-sharp signature spell a D#-minor scale. The warning does not
   make the file invalid, so this is easy to miss.

3. **Body-level (unbracketed) `K:` changes are ignored.** Lines 79 and 82 of
   9ccadbaf… contain `K:Bbm` (chorus key change). The checker warns and keeps
   using the header key `Fm`, so note names after that point are off by one
   accidental (G vs G♭).
   Blast radius: 1 file. Note this is also non-standard ABC (should be `[K:Bbm]`),
   so it is partly a score-style issue.

4. Minor: inline `Q:`/`P:`/`w:` fields are ignored with a warning; none occur in
   this corpus. Tuplets, chords, grace notes, `&` overlays, `[1`/`[2` endings and
   `%%` directives also do not occur, so the tokenizer's lack of support for them
   is untested here (not observed as a problem).

## Score-side findings

* **No genuine bar-length, unterminated-bar or voice-length errors anywhere.**
  No file has 0 voices/bars or empty output.
* 121 files use mid-body `M:` changes; all parse correctly and every bar matches
  its local meter.
* 32 files use the enharmonic minor keys `D#m`/`G#m`. These are valid ABC, just
  unconventional (E♭m / A♭m would be the usual spelling). No musical error.
* 9ccadbaf… uses two bare `K:Bbm` body lines where `[K:Bbm]` is standard.
* Every other file is clean under the checker.

## Verify with the patched checker

`/content/abc_report/abc_check_patched.py` fixes defects 1 and 2 (bracketed
inline fields; extended key table, including double sharps for theoretical keys):

```
patched invalid: 0 of 177
```

So after the checker fixes, the whole corpus validates. There is no evidence of
a bad score in the set.

## Artifacts

| file | contents |
|---|---|
| `abc_report/check_all.log` | full stdout of `check` for all 177 files |
| `abc_report/summary.csv` | per-file exit code, voices, bars, onsets, warnings |
| `abc_report/all_results.json` | raw results (command output, exit code, stderr) |
| `abc_report/abc_check_patched.py` | patched checker used to confirm the diagnosis |

## Applied patch to abc_check.py

1. Before tokenising each body line, extract and apply
   `\[([A-Za-z]):([^\]]*)\]` (at minimum `K`, also `M`/`L`), then remove it from
   the text.
2. Add `"G#": 8, "D#": 9, "A#": 10, "E#": 11, "B#": 12, "Fb": -8` to
   `MAJOR_SHARPS`, and allow `n > 7` / `n < -7` to produce double accidentals
   (the patched file shows the minimal change).
3. Optionally treat a bare body-level `K:` as a key change for the current voice
   instead of warning, to match what transcribers emit.

All three are now in `/content/abc_check.py`; the "Fixes" paragraph at the top of
that file documents them.
