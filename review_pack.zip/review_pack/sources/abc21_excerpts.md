# ABC 2.1 source excerpts used in `03_error_causes.md`

Source: *The abc music standard 2.1 (Dec 2011)*, Chris Walshaw,
<http://abcnotation.com/wiki/abc:standard:v2.1>, fetched 2026-10-27
(HTTP 200 via the `webfetch` tool; raw tool capture kept at
`/root/.local/share/opencode/tool-output/tool_17c34570d001EnB3H83QFAZrUu`,
outside this pack). Quotations below are verbatim.

## §3.2 Use of fields within the tune body

> It is often desired to change the key (K), meter (M), or unit note length (L)
> mid-tune. These, and most other information fields which can be legally used
> within the tune body, can be specified as an inline field by placing them
> within square brackets in a line of music

> Example: The following two excerpts are considered equivalent - either variant
> is equally acceptable.
>
> ```
> E2E EFE|E2E EFG|[M:9/8] A2G F2E D2|]
> E2E EFE|E2E EFG|\
> M:9/8
> A2G F2E D2|]
> ```

> The first bracket, field identifier and colon must be written without
> intervening spaces. Only one field may be placed within a pair of brackets;

## Information-field usage table (§3.1)

The table row for key reads (columns: file header / tune header / tune body /
inline):

> `K:key    last    yes    yes    instruction    K:G, K:Dm, K:AMix`

i.e. `K:` is legal in the tune body and as an inline field. The same table marks
`L:` and `M:` as legal in body and inline.

## §3.1.14 K: - key

> The key signature should be specified with a capital letter (A-G) which may be
> followed by a # or b for sharp or flat respectively. In addition the mode
> should be specified (when no mode is indicated, major is assumed).
>
> For example, K:C major, K:A minor, K:C ionian, K:A aeolian, K:G mixolydian,
> K:D dorian, K:E phrygian, K:F lydian and K:B locrian would all produce a staff
> with no sharps or flats. The spaces can be left out, capitalisation is ignored
> for the modes and in fact only the first three letters of each mode are parsed
> so that, for example, K:F# mixolydian is the same as K:F#Mix or even K:F#MIX.
> As a special case, minor may be abbreviated to m.

Key-signature table rows relevant to this pack:

> ```
>  6 sharps        F#  D#m  C#Mix  G#Dor  A#Phr  BLyd   E#Loc
>  5 sharps        B   G#m  F#Mix  C#Dor  D#Phr  ELyd   A#Loc
> ```

So `K:D#m` = 6 sharps and `K:G#m` = 5 sharps by the standard.

## Consequence for the reviewer's two test files

Because "capitalisation is ignored for the modes" and "only the first three
letters of each mode are parsed", `K:G Dorian` must be Dorian (1 flat) and
`K:A Minor` must be minor (0 sharps). **Both the original and my version print
`K:G Dorian … (key signature: F#)` and `K:A Minor … (key signature: F#, C#, G#)`
— see `06_manual_tests.txt`.** Neither version implements that sentence; this is
a pre-existing limitation that my "Fixes" block does not claim to address, and
is listed in `08_limits.md`.
