# 06 — Notes on the (unavailable) harness

## FAIL rows in the `new` column

**There are no rows at all**, because `review_tests.py` is absent (see
`06_harness.md`). I cannot state per-row verdicts for a harness I never
received, and I will not invent them. This is the exact reason the task could
not be completed, not a silent skip.

## The two manual files the request specifies

Both versions agree with each other and disagree with ABC 2.1:

```
dorian.abc   (K:G Dorian)   both scripts: key signature: F#
aminor.abc   (K:A Minor)    both scripts: key signature: F#, C#, G#
```

Full raw output: `06_harness_raw/manual_tests_copy.txt` (identical to
`06_manual_tests.txt`).

**Verdict: the script is wrong, the expectation is right.** ABC 2.1 §3.1.14
(`sources/abc21_excerpts.md`) says capitalisation of modes is ignored and only
the first three letters are parsed. `G Dorian` therefore has the same signature
as `G Dor` / `G dor`: one flat (`Bb`). `A Minor` is `A m`: no sharps/flats.
Both scripts instead fall through to "no mode = major", giving G major (F♯) and
A major (F♯ C♯ G♯).

Why both fail: the mode alternation in `key_signature()` is

```python
re.match(r"^\s*([A-G][#b]?)\s*(maj|min|mix|dor|lyd|phr|loc|m)?", k)
```

— lowercase only, and `re.match` is unanchored at the end, so an unrecognised
suffix is silently treated as major. This defect is **pre-existing** in the
original and was not touched by my changes; it is not claimed in the docstring.

If the reviewer's harness contains these two cases as PASS expectations, both
columns will FAIL them. I did not patch this in `abc_check.py` (no new fixes
allowed in this pass); a proposal is in `abc_check_proposed.py` /
`07_proposal.md`, clearly separate.

## What else I could not assess

The harness's PASS expectations for `[M:]`, `[L:]` and inline `[V:]` are unknown
to me, so I cannot say whether my implementation would satisfy them. See
`08_limits.md`.
