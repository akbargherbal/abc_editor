# 04 — Census of constructs across the 177-file corpus

Command (run from `/content`; script included at `tools/census.py`):

```
python3 review_pack/tools/census.py
```

## Headline counts

| construct | occurrences | files |
|---|---:|---:|
| inline `[V:` | 0 | 0 |
| inline `[K:` | 2 | 1 (`9ccadbaf…`, lines 185 & 187) |
| inline `[M:` | 0 | 0 |
| inline `[L:` | 0 | 0 |
| any other inline `[X:` | 0 | 0 |
| body-level `K:` | 2 | 1 (`9ccadbaf…`, lines 79 & 82) |
| body-level `M:` | 1380 | 121 |
| body-level `L:` / `Q:` / `W:` / `w:` | 0 | 0 |
| body-level `V:` (voice switches) | 12744 | 177 |
| **`M:` arriving with an open bar** | **0** | **0** |
| `M:` arriving at a barline | 1380 | 121 |
| tuplets `(2`…`(9` | 0 | 0 |
| chord brackets `[CEG]` | 0 | 0 |
| grace notes `{` | 0 | 0 |
| broken rhythm `>` / `<` | 0 | 0 |
| `%%` directives | 0 | 0 |
| files with more than one `X:` | 0 | 0 |
| voice names | `Vocal` 6549, `Ins` 6549 | 177 each |

**Key consequence for Task 5:** the corpus contains **zero** `M:` lines that
arrive while a bar is open. All 1380 body-level `M:` changes sit at a barline
(the preceding music line of that voice ends with `|`). Therefore the
"defer mid-bar M" change affects the result of **0 corpus files**.
[VERIFIED: `04_census.md` section C; `matrix.csv`]

Distinct `K:` values (section D): `Dm 72`, `D#m 31`, `Gm 28`, `Cm 20`, `Fm 17`
(15 headers + 2 inline), `Em 4`, `Bbm 4` (2 headers + 2 body), `Am 3`, `G#m 1`,
`Bm 1`. Only `D#m` and `G#m` are unrecognised by the original
(`orig_recognised=False`). No value contains a long mode name, a capitalised
mode, `exp`, `clef`, `HP`, `Hp`, or `none`.

## Full verbatim output

```
========================================================================
A. INLINE FIELDS  (pattern: \[[A-Za-z]:...)
========================================================================

[V:] occurrences=0 files=0
  (none)

[K:] occurrences=2 files=1
  9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd line 185: Z|z4[K:Fm]z4|
  9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd line 187: Z|z4[K:Fm]z4|

[M:] occurrences=0 files=0
  (none)

[L:] occurrences=0 files=0
  (none)

other [X:] inline fields occurrences=0
  (none)

========================================================================
B. BODY-LEVEL FIELD LINES (after the header K: line)
========================================================================

K: occurrences=2 files=1
  9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd line 79: K:Bbm
  9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd line 82: K:Bbm
  9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd

M: occurrences=1380 files=121
  016ff6c5-d575-4c39-88a9-c6052fabc68c
  0236acdb-57e5-4452-8aaa-fa43659d8b5e
  053f9170-ae50-42d1-ba88-f6fede4ba01a
  05ded404-a6b0-4380-9147-2c256ed32a31
  063bfab6-2791-4c80-b8ed-e65bcd6cac88
  0b3d3b91-6e68-44f0-b4c8-e6b9b4291da9
  0be82bf8-c5e1-4167-ac70-e031c9f8022c
  0c5f5113-e7f0-4692-9e45-bb41eb7a739e
  0d7261f9-ef35-4896-a62b-06c2420b69cc
  0f3c18de-a817-4b6d-af7e-8dbd383348b9
  100eb2ec-8574-43b7-9067-4bc816d28f50
  11689dd0-7dd9-4beb-a127-b9f14bf60076
  119f56d2-ff83-43bd-ae62-5a01357e8f7e
  11cbae01-1268-4877-9dd4-77a4095a07ef
  14f449b2-66c3-4200-af25-fc733ca20b55
  193a1a02-4bc0-4141-9bb8-94cb9c7e036f
  1a4000af-94f8-4418-8c54-141449893607
  1b956cd0-8f9e-4b5c-a00c-9f859e0b7bbc
  1bfc9d7a-cbd5-47f2-835c-dea015b8f302
  1c04c6a7-8936-41c8-908e-6fe05b9a01b8
  1dc18a60-064a-4949-9511-f6979aa2ed2c
  20f51999-185a-4ed0-8081-35523a40cc5c
  24c3c03f-3e11-4c18-8b44-21ad9e1ec01c
  2701b683-9a51-4512-aaf3-d269235d83de
  272ac238-23d6-4d57-a35c-f0b53049e9d9
  28df4f0d-1d66-45b1-8766-d457cc45da48
  2b572817-81bb-4f3b-b144-62d4f188d854
  2d92522f-22d9-482a-907e-cdec44ff9f7f
  33075ff2-41ea-44a0-a3b9-9dbd981665fb
  3a73cc7c-b896-431e-9c02-dea19cfa501b
  3ba505d0-9602-43e0-9edd-0540c462b274
  4142abaf-63c4-4c01-b8df-15ed597679d2
  449afa78-590e-4dd9-bd2f-2b309be01282
  454a9971-b8ff-4ba0-9cab-87d59c35d6be
  4a130201-183f-41b4-9a7d-a55f6df182b6
  504d6b9f-7a4a-4da8-999f-da5bfe65240f
  51aa3856-0b16-42cc-ac94-32f17b557eff
  541050d9-0dde-4f90-a650-2352ab8a0b19
  54547980-537c-46b7-ba43-90950ec21f4c
  576c8a9b-8e82-4b78-81a8-36702569804a
  57d701a2-ae75-4134-8c12-3260f099dceb
  5c95182f-3f75-4314-a4e4-a493ac775861
  5d6df40d-fb96-4c68-a534-6970195ec2f7
  5dbd23ba-8e4e-4f32-8ab1-dc22683795ff
  602452a5-a8cf-4b93-97f5-8ece887f69cd
  60d31c7c-4383-454b-bd7c-0d057c40eec5
  64e07a2f-1226-4044-b786-1b7ebc1d44e2
  678768d6-e4b7-4451-9041-964dc5501fae
  67eea3e0-92fc-4211-a716-a555f9201340
  6939ec66-69cc-456c-91fc-b11b8bc76fab
  6c93c118-fd8d-430b-8fb9-7e0bc86ac50b
  6d35a1fb-eb94-44d8-9fa6-aa479eef4746
  6f712976-9538-4cbb-a591-ffac5154dac3
  6fce90eb-5e78-42cc-a418-a2e00d347d03
  71528061-ed24-458d-b048-1f4098e30665
  72283fe1-2b5f-4268-bd72-5442484204e1
  735e2ee5-14e6-4a87-8cc5-417d252946c3
  73a8ecd4-938c-4aa7-a25e-7feaf2652e60
  75505f24-e992-46db-bc3f-2fbd44e85197
  7666435c-5831-477a-b8fa-b5b9d463797d
  78563c96-a675-4d9a-a33d-ca2b271eb24c
  7a38d7b6-72ce-4363-a79d-ab30da93bd06
  7abae477-6a78-41f4-a907-ce2ee0c44c6a
  7fbb69d1-013e-4a2f-9bb8-e11ebd520705
  81718edc-28a9-4f7f-a1f5-9cd80c6fe281
  83b06886-ddc6-4c02-a184-3abac266f40f
  852d1761-03df-4025-a056-8ad28afbbed0
  8a4067d8-f886-416d-ac29-cfcce38c6614
  8ea19939-73b9-49f7-a9c9-654837016d23
  8fd0080d-3a3a-4497-9974-d34098691912
  91d8da7f-5d9d-4ee2-8d79-0be4e52740bd
  925bfe3d-c51c-482d-ad23-dcfdfc0ae094
  95e97d67-995b-4d84-a765-6cc38764e58a
  982e3dca-3146-43b6-9c73-e2a810c128a6
  997d739d-88c6-4302-9da2-6e68da6678ac
  99dd0dab-38a5-48cf-b97b-c5d4d9e06f8a
  9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd
  9fa58db4-44ab-4b69-b5ba-8c0ad5e321e8
  a006b38f-782b-4ae7-8687-e8ebf6a07ff5
  a02f74af-42d5-4c49-b161-bc4ec7884f8d
  a0ec5e91-5af8-4752-be4f-75cadb7fd82d
  a39c6b12-8e41-4760-8706-2182f27c254d
  a3e77982-8bc5-4790-8e0a-747cccb7e51b
  a4c75146-2727-4ff5-a399-ca8a2bb31bab
  a5ef80bd-c453-4e19-8f40-b960da341296
  a71bc352-8b1e-40eb-85ad-f61fea34ed16
  a7687476-8a48-4f00-b8dd-cf8c1f588efa
  a9382ab5-feab-44bc-93a4-8c6cafacd7b1
  a993d1d7-7ee7-4bdd-98d1-15828f8cf154
  ac33993c-981b-4ee3-a4bb-1f281f41f577
  ae172c10-d824-4ac5-b686-c9b5d2802b5d
  b0798698-55e9-421f-8e47-0c3b6711deb3
  b0e7b4ce-5a61-4562-b415-69187cde1a3d
  b9824a78-a15e-4f0e-a9df-388d0d3b0bc6
  b9e9154b-eb38-4708-b72f-b5788b16b0aa
  ba64287a-ccc3-48ee-a5e7-6ee30b2d41d5
  bb17d099-457c-412f-a05e-fee7b3297a6d
  bb558334-42db-4d92-9ae3-e640979df49d
  bfee36f8-0838-4d12-853e-81f6d8426a5e
  cb456914-7b93-4265-af76-824ad11eeb6e
  cbd1a391-6976-4b32-8252-fbb7a1fd26e4
  cf386f8b-ef6b-409e-95eb-1e85a585c418
  d0fd493c-cada-4dc7-84b3-674abc529db7
  d170eca3-4643-4077-95a3-97cc28ab5409
  d1dc51bc-eb80-4927-95dd-73873939965c
  d8a7a117-e067-4030-9628-9088f255dfa7
  e1e8c547-5123-462b-9934-ed0eac2ce77e
  e42095b4-fe57-4816-90a8-b74d029b4d1d
  e67207bc-e062-4483-992a-30aef2731097
  e8d9bf7d-266e-4c40-8d2e-a953a79bf818
  eb3a4734-d517-478a-a3ed-ec8db172a6c9
  eb7d58d0-e2a5-4894-a34a-c97c6b13ed58
  f29aec22-0f5c-46b4-9b27-5e83602ad5c8
  f2cae6e5-d7fd-432c-b170-39b5c0ffbff3
  f554aecc-71f0-4e64-87fe-7f5cd8c925e0
  f59546b6-afa8-4139-a1b2-a3f9a6160f23
  f81c9bc0-60d0-4d01-8bb4-e5dfc7aec42a
  f8293491-f125-48cd-b82e-77cd0460a0cb
  f9fa236d-6527-4424-9396-36ff27b1ac13
  fb22ed16-506f-460f-9eba-365a43394120
  fb45843d-59fb-4e2e-9221-6874c8baf85c

L: occurrences=0 files=0
  (none)

Q: occurrences=0 files=0
  (none)

V: occurrences=12744 files=177
  016ff6c5-d575-4c39-88a9-c6052fabc68c
  01821d42-8748-461e-bbf5-5abb2b82fb74
  0236acdb-57e5-4452-8aaa-fa43659d8b5e
  037bb7d8-dadf-42da-8da5-ca04aec35a6f
  046fa27f-5614-47c9-a3a6-634fc99bdde4
  053f9170-ae50-42d1-ba88-f6fede4ba01a
  05b2c11d-e7bb-4c54-acc8-5d57695d57d7
  05ded404-a6b0-4380-9147-2c256ed32a31
  063bfab6-2791-4c80-b8ed-e65bcd6cac88
  0b3d3b91-6e68-44f0-b4c8-e6b9b4291da9
  0be82bf8-c5e1-4167-ac70-e031c9f8022c
  0c5f5113-e7f0-4692-9e45-bb41eb7a739e
  0d65f2cd-b7f4-4a6c-bd14-930fccf5b996
  0d7261f9-ef35-4896-a62b-06c2420b69cc
  0f3c18de-a817-4b6d-af7e-8dbd383348b9
  100eb2ec-8574-43b7-9067-4bc816d28f50
  101835bb-8918-4592-b542-2b13d5d86c2d
  101c3b2f-e27c-43ad-9a39-a32554ee6bce
  11689dd0-7dd9-4beb-a127-b9f14bf60076
  119f56d2-ff83-43bd-ae62-5a01357e8f7e
  11cbae01-1268-4877-9dd4-77a4095a07ef
  13fae855-2a2d-4410-a272-6101a3b9653d
  14f449b2-66c3-4200-af25-fc733ca20b55
  18bb8530-6097-48c3-8d5b-14740e3fcbac
  193a1a02-4bc0-4141-9bb8-94cb9c7e036f
  1a4000af-94f8-4418-8c54-141449893607
  1b956cd0-8f9e-4b5c-a00c-9f859e0b7bbc
  1bfc9d7a-cbd5-47f2-835c-dea015b8f302
  1c04c6a7-8936-41c8-908e-6fe05b9a01b8
  1dc18a60-064a-4949-9511-f6979aa2ed2c
  20f51999-185a-4ed0-8081-35523a40cc5c
  22bc8925-f43c-4cc1-a34d-e65933bdfc24
  240c0a6f-fb17-4715-b787-5994f2ff1f7b
  24c3c03f-3e11-4c18-8b44-21ad9e1ec01c
  2701b683-9a51-4512-aaf3-d269235d83de
  272ac238-23d6-4d57-a35c-f0b53049e9d9
  28df4f0d-1d66-45b1-8766-d457cc45da48
  2b572817-81bb-4f3b-b144-62d4f188d854
  2d92522f-22d9-482a-907e-cdec44ff9f7f
  33075ff2-41ea-44a0-a3b9-9dbd981665fb
  3a73cc7c-b896-431e-9c02-dea19cfa501b
  3ba505d0-9602-43e0-9edd-0540c462b274
  4142abaf-63c4-4c01-b8df-15ed597679d2
  417613c0-cf0d-4339-91f2-74d80eff627f
  449afa78-590e-4dd9-bd2f-2b309be01282
  454821ac-8656-4322-b31f-09094fee22b8
  454a9971-b8ff-4ba0-9cab-87d59c35d6be
  462cddd0-3f77-4643-a3ef-f4b45d160616
  4a130201-183f-41b4-9a7d-a55f6df182b6
  504d6b9f-7a4a-4da8-999f-da5bfe65240f
  5184e33a-2f3b-4672-b578-8c2685e3deb8
  51aa3856-0b16-42cc-ac94-32f17b557eff
  541050d9-0dde-4f90-a650-2352ab8a0b19
  54547980-537c-46b7-ba43-90950ec21f4c
  56ec90f9-eedc-493d-aafd-eb5c2b76f9ef
  57012957-7e5f-4d68-9a74-965b8f811e43
  576c8a9b-8e82-4b78-81a8-36702569804a
  57d701a2-ae75-4134-8c12-3260f099dceb
  5a30fe55-88d8-4939-86c0-b8ebfaa07f75
  5c95182f-3f75-4314-a4e4-a493ac775861
  5d6df40d-fb96-4c68-a534-6970195ec2f7
  5dbd23ba-8e4e-4f32-8ab1-dc22683795ff
  602452a5-a8cf-4b93-97f5-8ece887f69cd
  60d31c7c-4383-454b-bd7c-0d057c40eec5
  64e07a2f-1226-4044-b786-1b7ebc1d44e2
  657ca6e5-7e77-4d52-a9dd-006521a751d5
  65cc7839-1947-46c6-b6f8-98e76a679911
  678768d6-e4b7-4451-9041-964dc5501fae
  67eea3e0-92fc-4211-a716-a555f9201340
  6939ec66-69cc-456c-91fc-b11b8bc76fab
  6ab44190-bb40-43ac-89b9-250947dad29f
  6c93c118-fd8d-430b-8fb9-7e0bc86ac50b
  6d35a1fb-eb94-44d8-9fa6-aa479eef4746
  6e9f9f4b-8683-456c-abae-b3f87060c9f8
  6f712976-9538-4cbb-a591-ffac5154dac3
  6fce90eb-5e78-42cc-a418-a2e00d347d03
  71528061-ed24-458d-b048-1f4098e30665
  71530287-d8e5-4fdc-bd2b-91ad53921c20
  72283fe1-2b5f-4268-bd72-5442484204e1
  735e2ee5-14e6-4a87-8cc5-417d252946c3
  73a8ecd4-938c-4aa7-a25e-7feaf2652e60
  75505f24-e992-46db-bc3f-2fbd44e85197
  761e93da-af83-4b9c-847d-75f697071dc0
  7666435c-5831-477a-b8fa-b5b9d463797d
  78563c96-a675-4d9a-a33d-ca2b271eb24c
  7a38d7b6-72ce-4363-a79d-ab30da93bd06
  7abae477-6a78-41f4-a907-ce2ee0c44c6a
  7eb506a8-d550-449b-abd8-e873b7db3058
  7fbb69d1-013e-4a2f-9bb8-e11ebd520705
  81718edc-28a9-4f7f-a1f5-9cd80c6fe281
  833153ed-2211-44ac-bb99-ab0fe658c64e
  83b06886-ddc6-4c02-a184-3abac266f40f
  852d1761-03df-4025-a056-8ad28afbbed0
  85895ab9-de6a-45f6-88a1-8431d0e99c25
  8a4067d8-f886-416d-ac29-cfcce38c6614
  8ea19939-73b9-49f7-a9c9-654837016d23
  8fd0080d-3a3a-4497-9974-d34098691912
  9199baa3-5b69-4b56-b0e4-2cecc222428a
  91d8da7f-5d9d-4ee2-8d79-0be4e52740bd
  925bfe3d-c51c-482d-ad23-dcfdfc0ae094
  95e97d67-995b-4d84-a765-6cc38764e58a
  982e3dca-3146-43b6-9c73-e2a810c128a6
  997d739d-88c6-4302-9da2-6e68da6678ac
  99dd0dab-38a5-48cf-b97b-c5d4d9e06f8a
  9ccadbaf-052b-4683-9bf3-0ca2da5c9ddd
  9fa58db4-44ab-4b69-b5ba-8c0ad5e321e8
  a006b38f-782b-4ae7-8687-e8ebf6a07ff5
  a02f74af-42d5-4c49-b161-bc4ec7884f8d
  a0ec5e91-5af8-4752-be4f-75cadb7fd82d
  a39c6b12-8e41-4760-8706-2182f27c254d
  a3e77982-8bc5-4790-8e0a-747cccb7e51b
  a4c75146-2727-4ff5-a399-ca8a2bb31bab
  a5ef80bd-c453-4e19-8f40-b960da341296
  a71bc352-8b1e-40eb-85ad-f61fea34ed16
  a7687476-8a48-4f00-b8dd-cf8c1f588efa
  a9382ab5-feab-44bc-93a4-8c6cafacd7b1
  a993d1d7-7ee7-4bdd-98d1-15828f8cf154
  a9ae9827-5204-45bb-bea4-9c1535333ae4
  aaba7884-c88e-4e5b-bd07-ed824935e68f
  ac33993c-981b-4ee3-a4bb-1f281f41f577
  ae172c10-d824-4ac5-b686-c9b5d2802b5d
  b0798698-55e9-421f-8e47-0c3b6711deb3
  b0e7b4ce-5a61-4562-b415-69187cde1a3d
  b9824a78-a15e-4f0e-a9df-388d0d3b0bc6
  b9e9154b-eb38-4708-b72f-b5788b16b0aa
  ba64287a-ccc3-48ee-a5e7-6ee30b2d41d5
  bb17d099-457c-412f-a05e-fee7b3297a6d
  bb558334-42db-4d92-9ae3-e640979df49d
  bdc1f0fa-e598-4ba0-8bbd-afbcc2b74556
  bf08727a-0be7-44af-8c66-07ff3e7e7bc3
  bfee36f8-0838-4d12-853e-81f6d8426a5e
  c319b28c-1b8f-47fb-b290-c7441fe94a11
  c35b1038-50c1-448e-80c0-7db40b0b8a8b
  c387054b-a32c-4235-9968-bc2169e148ef
  c39fb0d8-99f1-457f-975d-a67df9e5db28
  c514afde-c461-4b18-9f76-5b29b8f6330d
  c54d343c-2884-4fd3-947a-cb3dbda1fec8
  c5907965-83ff-4a54-b19e-66baff20202d
  c8d7c51c-07b5-41b7-824e-b040a563efbe
  cb2bb293-000c-4a19-9b6d-13c319b3aca2
  cb456914-7b93-4265-af76-824ad11eeb6e
  cbd1a391-6976-4b32-8252-fbb7a1fd26e4
  cd3dd7eb-233f-4c99-86b9-4453cc1d1d1a
  cf386f8b-ef6b-409e-95eb-1e85a585c418
  d0fd493c-cada-4dc7-84b3-674abc529db7
  d170eca3-4643-4077-95a3-97cc28ab5409
  d1dc51bc-eb80-4927-95dd-73873939965c
  d6cddb24-2c81-42ca-af8d-4937f1f85a64
  d8a7a117-e067-4030-9628-9088f255dfa7
  dd276693-566b-48b6-a6bd-4bfb2272f634
  e1b1d293-f7c3-456f-8bbf-58103dabec58
  e1e8c547-5123-462b-9934-ed0eac2ce77e
  e3f837bc-99cc-4187-8adc-fa624abde685
  e42095b4-fe57-4816-90a8-b74d029b4d1d
  e4a4138a-ff90-4a1c-9103-18a8e41ca3f6
  e67207bc-e062-4483-992a-30aef2731097
  e869fe9e-0477-4c9d-a02a-ab244179bd94
  e8b11df7-4e5f-403d-811c-304def7281a1
  e8d9bf7d-266e-4c40-8d2e-a953a79bf818
  e93b45c9-c796-4a82-bc3a-2510fcb01c99
  eb3a4734-d517-478a-a3ed-ec8db172a6c9
  eb7d58d0-e2a5-4894-a34a-c97c6b13ed58
  ec4b360e-ccdd-45b3-a6d5-19d66b04167c
  ee572380-e54e-4b1d-8cea-9d9e747d11e9
  f29aec22-0f5c-46b4-9b27-5e83602ad5c8
  f2cae6e5-d7fd-432c-b170-39b5c0ffbff3
  f44c781f-c84e-43c1-8e54-f5d2b7cf81f3
  f554aecc-71f0-4e64-87fe-7f5cd8c925e0
  f59546b6-afa8-4139-a1b2-a3f9a6160f23
  f6784753-d127-45ec-9c1e-f0c59c4ae9e9
  f81c9bc0-60d0-4d01-8bb4-e5dfc7aec42a
  f8293491-f125-48cd-b82e-77cd0460a0cb
  f999957f-6c18-4655-bda1-7f9bad82e6f6
  f9cb7bf5-2b9e-4f2f-a9ed-11f6932851e9
  f9fa236d-6527-4424-9396-36ff27b1ac13
  fb22ed16-506f-460f-9eba-365a43394120
  fb45843d-59fb-4e2e-9221-6874c8baf85c

W: occurrences=0 files=0
  (none)

w: occurrences=0 files=0
  (none)

========================================================================
C. BODY-LEVEL M: LINES ARRIVING WHILE A BAR IS OPEN
  (preceding music line of that voice does not end with '|')
========================================================================
open-bar M: lines = 0
closed/at-barline M: lines = 1380

========================================================================
D. DISTINCT K: VALUES (header, body and inline)
========================================================================
  occurrences= 72 files= 72  'Dm'  flags=none  orig_recognised=True  orig_sig=Bb
  occurrences= 31 files= 31  'D#m'  flags=none  orig_recognised=False  orig_sig=none
  occurrences= 28 files= 28  'Gm'  flags=none  orig_recognised=True  orig_sig=Bb, Eb
  occurrences= 20 files= 20  'Cm'  flags=none  orig_recognised=True  orig_sig=Bb, Eb, Ab
  occurrences= 17 files= 15  'Fm'  flags=none  orig_recognised=True  orig_sig=Bb, Eb, Ab, Db
  occurrences=  4 files=  4  'Em'  flags=none  orig_recognised=True  orig_sig=F#
  occurrences=  4 files=  3  'Bbm'  flags=none  orig_recognised=True  orig_sig=Bb, Eb, Ab, Db, Gb
  occurrences=  3 files=  3  'Am'  flags=none  orig_recognised=True  orig_sig=none
  occurrences=  1 files=  1  'G#m'  flags=none  orig_recognised=False  orig_sig=none
  occurrences=  1 files=  1  'Bm'  flags=none  orig_recognised=True  orig_sig=F#, C#

========================================================================
E. OTHER CONSTRUCTS
========================================================================

tuplets (2..9: occurrences=0 files=0

chord brackets [CEG]: occurrences=0 files=0

grace notes {: occurrences=0 files=0

broken rhythm > or <: occurrences=0 files=0

%% directive: occurrences=0 files=0

X: count > 1 (multiple tunes per file)
  files=0

voice names (first token after V:)
  occurrences=6549  'Vocal'  files=177
  occurrences=6549  'Ins'  files=177
```
