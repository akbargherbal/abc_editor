# 05 — Inventory of behavioural changes

`05_diff.patch` is the verbatim `diff -u` of the two scripts
(13 hunks). Docstring "Fixes" bullets are numbered as in `abc_check.py`:

- **F1** inline bracketed fields (`[K:]` / `[M:]` / `[L:]`; phantom-note bug)
- **F2** bare body-level `K:` changes the key for the current voice
- **F3** `MAJOR_SHARPS` covers `G# D# A# E# B#` / `Fb`, double accidentals

## Hunk-by-hunk

| # | diff hunk | what it changes | maps to | documented? |
|---|---|---|---|---|
| H1 | `@@ -17,6 +17,19 @@` | adds the "Fixes" block to the module docstring | documentation of F1–F3 | n/a (is the documentation) |
| H2 | `@@ -29,6 +42,7 @@` | adds an `inline` alternative to `TOKEN`: `\[(?P<ifield>[A-Za-z]):(?P<ival>[^\]]*)\]` | F1 | yes |
| H3 | `@@ -39,7 +53,9 @@` | adds `G# 8, D# 9, A# 10, E# 11, B# 12, Fb -8` to `MAJOR_SHARPS` | F3 | yes |
| H4 | `@@ -62,11 +78,16 @@` | `key_signature()`: caps at 7 accidentals and adds `2`/`-2` for signatures wider than 7 | F3 | yes |
| H5 | `@@ -90,6 +111,8 @@` | `Voice.keysig`, `Voice.pending_meter` | F1 (`pending_meter`), F2/F3 (`keysig`) | partly — the fields themselves are not named |
| H6 | `@@ -101,9 +124,52 @@` | `Score.key_changes`; new `keysig_text()`, `set_key()`, `inline_field()` | F1, F2, F3 | yes for K/M/L; **see H6 note** for `[V:]`/other fields |
| H7 | `@@ -150,9 +216,12 @@` | **bare body-level `M:` while a bar is open**: no longer `close_bar(..., unterminated=True)` → hard error; now keeps the open bar under the old meter, stores `pending_meter`, emits a warning | — | **UNDOCUMENTED** |
| H8 | `@@ -163,7 +232,9 @@` | bare body-level `K:` no longer warns "ignored/unsupported"; calls `set_key()` | F2 | yes |
| H9 | `@@ -173,7 +244,9 @@` | token loop dispatches `t.group("inline")` to `inline_field()` before bar/note handling | F1 | yes |
| H10 | `@@ -200,7 +273,9 @@` | `ensure_voice()` initialises the new voice's `keysig` from the header signature | F2/F3 support | implied, not stated |
| H11 | `@@ -213,7 +288,8 @@` | `add_note()` uses the voice's key signature when present, else the score's | F2/F3 support | implied, not stated |
| H12 | `@@ -233,6 +309,9 @@` | `close_bar()` applies `pending_meter` after the bar closes | F1 (inline `[M:]` deferral) | yes for inline; no for bare `M:` (H7) |
| H13 | `@@ -307,8 +386,10 @@` | `check` prints key signatures via `keysig_text()` and adds a `KEY CHANGES:` line | reporting aid, not a fix | **UNDOCUMENTED** |

### H6 note — inline fields other than K/M/L

`inline_field()` applies `K`, `M`, `L`; **any other** inline field (e.g.
`[V:…]`, `[Q:…]`, `[P:…]`) now produces one
`WARNING: line N: inline field X: ignored/unsupported` instead of one
`unsupported token` **error** per character. The docstring sentence "Inline
bracketed fields are now parsed" is broader than what is implemented: `[V:]` is
*not* applied. No corpus file uses an inline field other than `[K:]`
(`04_census.md` §A), so this has zero effect on the matrix, but it is a
**weakening of validation** that is only partly documented.

## The reviewer's observation: bare `M:` with an open bar

**What changed (H7).** Original:

```python
else:
    if cur.cur:
        close_bar(sc, cur, unterminated=True)
    cur.meter = mt
```

`close_bar(..., unterminated=True)` marks the open bar
`"unterminated": True`, and `validity()` turns that into
`"bar N: bar not closed with a barline"` → exit 1.

New:

```python
elif cur.cur:
    cur.pending_meter = mt
    sc.warnings.append(f"line {ln}: mid-bar M:{val} deferred to next bar")
else:
    cur.meter = mt
```

The open bar is closed normally (under the old meter); `close_bar()` applies
`pending_meter` afterwards. Result: warning, not error.

**Why.** (i) ABC 2.1 §3.2 treats a bare `M:` line in the body as equivalent to
`[M:]` ("either variant is equally acceptable"), so the presence of the field
should not itself invalidate the preceding bar. (ii) I wanted bare `M:` to
behave like the new inline `M:` path. (iii) A mid-bar meter change is
musically degenerate; deferring to the next barline is the least destructive
interpretation.

**Is it in the docstring?** **No.** F1's sentence mentions only the bracketed
form: "`[M:...]` applies immediately when the bar is still empty, otherwise it
is deferred to the next bar with a warning." The bare-body `M:` deferral (H7) is
**UNDOCUMENTED**. This is a genuine omission.

**How many corpus files depend on it?** **0.**
- Direct test: `tools/abc_check_no_h7.py` is `abc_check.py` with only H7 reverted
  to the original `close_bar(..., unterminated=True)` behaviour. Running `check`
  on all 177 files with it gives **byte-identical stdout and exit codes** to
  `abc_check.py` (`05_no_h7_check.txt`: `differences … 0`).
- `04_census.md` §C: `open-bar M: lines = 0`; all 1380 body `M:` lines are at a
  barline.
- `matrix.csv`: the only INVALID→VALID transition is `9ccadbaf…`, whose cause is
  `inline_K`; the 32 other changed files change only key/pitch reporting and
  keep `bars_changed = no`.
- Therefore no corpus result (exit code or validity) depends on H7.

**Risk if such a file existed:** the change converts a hard error (exit 1) into
a warning (exit 0). That is a validation-semantics change and is reported in
`08_limits.md`.

## Verdict on each docstring "Fixes" sentence

### F1, sentence 1 — "Inline bracketed fields are now parsed."

- Partly **verified**:
  - `[K:…]`: verified by `9ccadbaf…` (raw pair) — the field is applied and the
    phantom note disappears. `KEY CHANGES: line 185: Fm, line 187: Fm` appears
    in `raw/new/9ccadbaf….txt`.
  - `[M:…]` and `[L:…]`: **Not verified** against the corpus or the (absent)
    harness — the corpus has 0 of each (`04_census.md` §A). I did exercise them
    on a throw-away file in the earlier session, but that artifact is not in
    this pack, so by the rules of this pass they are **Not verified**.
- Overbroad: inline fields other than K/M/L are warned-and-dropped, not applied
  (H6 note).

### F1, sentence 2 — "`[M:...]` applies immediately when the bar is still empty, otherwise it is deferred to the next bar with a warning."

**Not verified** on real data (0 occurrences). Code path exists
(`inline_field()` + `close_bar()`), but no corpus file or supplied test
exercises it.

### F1, sentence 3 — "`[L:...]` applies immediately."

**Not verified** (0 occurrences in the corpus; no harness available).

### F1, sentence 4 — "Previously their contents were tokenised as music (e.g. the `F` in `[K:Fm]` became a phantom note that overflowed the bar)."

**Verified** by `raw/extra/bars_9ccad_original_Vocal.txt`
(`146 … z4Fz4 <-- BAD LENGTH`) versus
`raw/extra/bars_9ccad_new_Vocal.txt` (`146 … z4z4`), and by the onset counts
517 → 516 in `raw/original|new/9ccadbaf….txt`.

### F2 — "Bare body-level `K:` lines now change the key for the current voice instead of being ignored with a warning."

**Verified** by `9ccadbaf…`: new output adds
`KEY CHANGES: line 79: Bbm, line 82: Bbm`, and the Vocal histogram changes
`G 60` → `F# 72` (G→G♭ across the chorus), consistent with `Bbm`'s five flats
(`raw/original|new/9ccadbaf….txt`). The original, in contrast, printed
`WARNING: line 79: inline field K: ignored/unsupported`.

### F3, first sentence — "`MAJOR_SHARPS` now covers the theoretical sharp keys `G# D# A# E# B#` (and `Fb`), with double-accidental support for signatures wider than 7."

**Verified** by `raw/extra/keysig_checks.txt`: `D#m → F#, C#, G#, D#, A#, E#`,
`G#m → F#, C#, G#, D#, A#`, `B# → F##, C##, G##, D##, A##, E#, B#`,
`Fb → Bbb, Eb, Ab, Db, Gb, Cb, Fb`. The original returns `ok=False` for all of
these.

### F3, second sentence — "This fixes `K:D#m` / `K:G#m` being read as 'no key signature', which **silently** transposed pitch names and histograms by a semitone."

- "read as no key signature" and "transposed … by a semitone": **Verified** by
  the `01821d42…` raw pair (`key signature: none` → 6 sharps; histograms shift
  by +1 semitone).
- **"silently" is wrong.** The original printed
  `WARNING: K:D#m not recognised; pitch spelling may be off` for **31** files
  and `WARNING: K:G#m …` for 1 file (raw outputs; `03_error_causes.md` message
  table). The transposition was warned about; the file was still reported VALID.
  The docstring should say "misread with a warning", not "silently".

## Docstring claims not covered by any "Fixes" bullet

- H13 (`KEY CHANGES:` line and `keysig_text()` formatting) — UNDOCUMENTED
  output-format change.
- H7 (bare `M:` deferral) — UNDOCUMENTED validation-semantics change.
- H6's warn-and-drop for inline `[V:]`/`[Q:]`/etc. — only partly covered by F1.
